> How to install a mission.
Download a mission, and move it into the "Missions" folder.
Assuming it is valid, it will be available on the "Play Mission" menu.

> Error Codes.
001 | Either one of the following modules failed to be imported. "os, sys, importlib"
002 | Failed to insert system path.
003 | Unknown exception occured whilst loading mission.
004 | Other Error.
005 | Error whilst loading API.
006 | Error whilst loading a module.